<template>
  <div class="">
    rank
  </div>
</template>

<script>
export default {}
</script>

<style>

</style>
